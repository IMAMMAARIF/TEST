import React from 'react';
import { Smartphone, Laptop, Headphones, Camera, Watch, Gift, ShoppingBag, Home } from 'lucide-react';

const categories = [
  { id: '1', name: 'Electronics', icon: Smartphone },
  { id: '2', name: 'Computers', icon: Laptop },
  { id: '3', name: 'Audio', icon: Headphones },
  { id: '4', name: 'Cameras', icon: Camera },
  { id: '5', name: 'Wearables', icon: Watch },
  { id: '6', name: 'Gifts', icon: Gift },
  { id: '7', name: 'Fashion', icon: ShoppingBag },
  { id: '8', name: 'Home', icon: Home },
];

export default function Categories() {
  return (
    <div className="py-8 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-semibold mb-6">Categories</h2>
        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <button
                key={category.id}
                className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <IconComponent className="h-6 w-6 text-indigo-600 mb-2" />
                <span className="text-sm text-gray-700">{category.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}