import React from 'react';
import ProductCard from './ProductCard';
import type { Product } from '../types';

const products: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 299.99,
    description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    category: 'Audio',
    rating: 4.8,
    stock: 15
  },
  {
    id: '2',
    name: 'Smart Watch Pro',
    price: 399.99,
    description: 'Advanced smartwatch with health tracking and cellular connectivity.',
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
    category: 'Wearables',
    rating: 4.7,
    stock: 20
  },
  {
    id: '3',
    name: 'Professional Camera Kit',
    price: 1299.99,
    description: 'Professional-grade camera with multiple lenses and accessories.',
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
    category: 'Cameras',
    rating: 4.9,
    stock: 8
  },
  {
    id: '4',
    name: 'Ultra-thin Laptop',
    price: 1499.99,
    description: 'Powerful and portable laptop with long battery life.',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80',
    category: 'Computers',
    rating: 4.6,
    stock: 12
  }
];

export default function FeaturedProducts() {
  return (
    <div className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-semibold mb-6">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}